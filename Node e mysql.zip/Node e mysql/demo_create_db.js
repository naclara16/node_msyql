var mysql = require('mysql2'); //importando modulo mysql2
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
});

var criarDB = "CREATE DATABASE mydb"; //criando banco de dados

//executando código para criar banco de dados

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
    
    con.query(criarDB, function (err, result) {
        if (err) throw err;
        console.log("Database created ");
    });
});

