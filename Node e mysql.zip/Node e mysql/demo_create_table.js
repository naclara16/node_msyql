var mysql = require('mysql2');
var criarTB = `CREATE TABLE clientes (id INT AUTO_INCREMENT PRIMARY KEY, nome
VARCHAR(255), endereco VARCHAR(255))`;

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "mydb"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");

    con.query(criarTB, function (err, result) {
        if (err) throw err;
        console.log("Table created");
    });
});

//exemplo de alteração de tabela
/*con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "ALTER TABLE clientes ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY";
    con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table altered");
    });
   });*/